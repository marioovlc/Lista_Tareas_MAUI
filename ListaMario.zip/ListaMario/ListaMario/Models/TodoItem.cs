﻿namespace ListaMario.Models
{
    public class TodoItem
    {
        public string Title { get; set; }
        public bool IsCompleted { get; set; }
    }
}