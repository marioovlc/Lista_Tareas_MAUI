﻿using ListaMario.Models;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace ListaMario.ViewModels
{
    [QueryProperty(nameof(Items), "pItems")]
    public class AddItemNewWindowViewModel : BindableObject
    {
        private ObservableCollection<TodoItem> items;
        private string newTaskTitle;
        private bool isCompleted;

        public ObservableCollection<TodoItem> Items
        {
            get => items;
            set
            {
                items = value;
                OnPropertyChanged();
            }
        }

        public string NewTaskTitle
        {
            get => newTaskTitle;
            set
            {
                newTaskTitle = value;
                OnPropertyChanged();
            }
        }

        public bool IsCompleted
        {
            get => isCompleted;
            set
            {
                isCompleted = value;
                OnPropertyChanged();
            }
        }

        public ICommand AddItemCommand { get; }
        public ICommand CancelCommand { get; }

        public AddItemNewWindowViewModel()
        {
            AddItemCommand = new Command(async () =>
            {
                if (!string.IsNullOrWhiteSpace(NewTaskTitle))
                {
                    var newItem = new TodoItem { Title = NewTaskTitle, IsCompleted = IsCompleted };
                    Items.Add(newItem);
                    await Shell.Current.GoToAsync("///MainPage");
                }
                else
                {
                    // Opcional: Mostrar un missatge d'error si el títol de la tasca està buit
                    await Application.Current.MainPage.DisplayAlert("Error", "El títol de la tasca no pot estar buit.", "OK");
                }
            });

            CancelCommand = new Command(async () =>
            {
                await Shell.Current.GoToAsync("///MainPage");
            });
        }
    }
}