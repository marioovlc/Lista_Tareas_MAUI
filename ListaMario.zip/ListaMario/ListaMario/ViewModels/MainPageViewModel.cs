﻿using ListaMario.Models;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace ListaMario.ViewModels
{
    public class MainPageViewModel : BindableObject
    {
        private ObservableCollection<TodoItem> items;

        public ObservableCollection<TodoItem> Items
        {
            get => items;
            set
            {
                items = value;
                OnPropertyChanged();
            }
        }

        public ICommand AddItemCommandNewWindow { get; }
        public ICommand DeleteItemCommand { get; }

        public MainPageViewModel()
        {
            Items = new ObservableCollection<TodoItem>
            {
                new TodoItem { Title = "Comprar pa", IsCompleted = false },
                new TodoItem { Title = "Estudiar per l'examen", IsCompleted = true }
            };

            AddItemCommandNewWindow = new Command(async () =>
            {
                var navigationParameter = new Dictionary<string, object>
                {
                    { "pItems", Items }
                };
                await Shell.Current.GoToAsync("///AddItemNewWindow", navigationParameter);
            });

            DeleteItemCommand = new Command<TodoItem>(item =>
            {
                Items.Remove(item);
            });
        }
    }
}