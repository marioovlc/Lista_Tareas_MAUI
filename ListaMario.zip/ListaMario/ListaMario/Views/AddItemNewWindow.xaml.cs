﻿namespace ListaMario.Views
{
    public partial class AddItemNewWindow : ContentPage
    {
        public AddItemNewWindow()
        {
            InitializeComponent();
        }
    }
}